// in this header we define some necessary constant for CURL communication

#define COMM

#define URL "http://www.cc.puv.fi/~e1601110/php/sound.php"

void send_data_curl(double []);
